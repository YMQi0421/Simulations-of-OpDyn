##################### OpDyn #########################


The main code is "Main.py". 

## By setting the graph generation in the code "G = nx.barabasi_albert_graph" to SF or "nx.random_graphs.watts_strogatz_graph" to WS network, the results of Figs. 1-4 (corresponding to SF network) and Figs. 5-8 (corresponding to WS network) are obtained respectively. 

## The generated data is saved as a ".mat" file through the "Save_results.ipynb".

## All the figures are drawn in MATLAB. See the folder "Draw_Figures".



######### Github: https://github.com/ymqi-HIT/Simulations-of-OpDyn ##########